package com.example.taller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView mensaje;
    private EditText valor1;
    private EditText valor2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mensaje=findViewById(R.id.resultado);
        valor1=findViewById(R.id.caja1);
        valor2=findViewById(R.id.caja2);
    }
    public void mostrar(View view){
        String msj = valor1.getText().toString()+valor2.getText().toString();
        mensaje.setText(msj);
    }
    public void suma (View view){
        int sumas = Integer.parseInt(valor1.getText().toString()) + Integer.parseInt(valor2.getText().toString());
        mensaje.setText(sumas+"");
    }

}